# SOUQNA Crypto Telegram Bot

بوت تيليجرام عربي لمتابعة أسعار العملات، عرض المهام التي يضيفها المشرف، تسجيل نقاط داخلية، واستقبال طلبات سحب للمراجعة اليدوية.

## تشغيل محلي
1. ثبّت Python 3.11 أو أحدث.
2. نفّذ: `pip install -r requirements.txt`
3. انسخ `.env.example` إلى `.env` (أو عيّن متغيرات البيئة في نظامك).
4. عيّن `BOT_TOKEN` و`ADMIN_ID`.
5. شغّل: `python main.py`

## تشغيل Railway
1. ارفع ملفات المشروع إلى GitHub ثم اربط المستودع بـ Railway.
2. أضف في Variables:
   - `BOT_TOKEN`: توكن البوت من BotFather (سرّي).
   - `ADMIN_ID`: رقم حساب تيليجرام الخاص بالمشرف.
3. تأكد أن Start Command هو `python main.py` أو استخدم Procfile.
4. أضف Volume دائمًا، واجعل مساره `/app/data` ثم أضف المتغير `DB_PATH=/app/data/souqna_crypto.db` حتى لا تضيع قاعدة البيانات عند إعادة النشر.
5. اجعل الخدمة Worker وليس Web Service؛ هذا البوت يستخدم Telegram polling ولا يحتاج منفذ HTTP.

## أوامر المستخدم
- `/start` القائمة الرئيسية
- `/prices` أسعار BTC وETH وBNB وSOL
- `/tasks` المهام المتاحة
- `/balance` رصيد النقاط
- `/withdraw amount wallet_address` طلب سحب للمراجعة

## أوامر المشرف
- `/addtask العنوان | الوصف | الرابط`
- `/credit user_id amount`
- `/stats`
- `/approve request_id`
- `/reject request_id`

## تنبيهات مهمة
- لا تضع التوكن داخل الكود أو GitHub. خزّنه في Railway Variables.
- لا تطلب من المستخدمين كلمات المرور أو مفاتيح المحافظ أو عبارات الاسترداد.
- النقاط داخل البوت ليست أموالًا أو عملة رقمية. السحب لا يتم تلقائيًا؛ الموافقة تسجل الطلب فقط، والتحويل اليدوي يحتاج مراجعة مستقلة.
- المهام والروابط يضيفها المشرف بعد التحقق منها. لا توجد أرباح مضمونة.
