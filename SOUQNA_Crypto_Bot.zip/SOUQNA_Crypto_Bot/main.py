import os
import logging
import sqlite3
from datetime import datetime, timezone

import httpx
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, filters
)

TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0") or "0")
DB_PATH = os.getenv("DB_PATH", "souqna_crypto.db")

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO
)
log = logging.getLogger("souqna-crypto")


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
            points REAL NOT NULL DEFAULT 0, joined_at TEXT NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            description TEXT NOT NULL, url TEXT NOT NULL DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS withdrawals (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            amount REAL NOT NULL, wallet TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL
        )""")


def register_user(user):
    with db() as con:
        con.execute("""INSERT INTO users(user_id, username, first_name, joined_at)
            VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
            username=excluded.username, first_name=excluded.first_name""",
            (user.id, user.username or "", user.first_name or "",
             datetime.now(timezone.utc).isoformat()))


def is_admin(user_id):
    return ADMIN_ID != 0 and user_id == ADMIN_ID


def menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 أسعار العملات", callback_data="prices"),
         InlineKeyboardButton("🎯 المهام والفرص", callback_data="tasks")],
        [InlineKeyboardButton("💰 رصيدي", callback_data="balance"),
         InlineKeyboardButton("💸 طلب سحب", callback_data="withdraw_help")],
        [InlineKeyboardButton("ℹ️ طريقة الاستخدام", callback_data="help")]
    ])


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    register_user(update.effective_user)
    await update.message.reply_text(
        "أهلاً بك في SOUQNA Crypto 🚀\\n\\n"
        "بوت لمتابعة أسعار العملات والفرص والمهام التي يضيفها المشرف.\\n"
        "لا نضمن الأرباح، ولا تطلب منا كلمات المرور أو المفاتيح السرية أو عبارة استرداد المحفظة.",
        reply_markup=menu()
    )


async def prices_text():
    ids = "bitcoin,ethereum,binancecoin,solana"
    url = "https://api.coingecko.com/api/v3/simple/price"
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.get(url, params={"ids": ids, "vs_currencies": "usd"})
        response.raise_for_status()
        data = response.json()
    names = [("bitcoin", "Bitcoin"), ("ethereum", "Ethereum"),
             ("binancecoin", "BNB"), ("solana", "Solana")]
    lines = ["📊 أسعار العملات التقريبية بالدولار:"]
    for key, label in names:
        value = data.get(key, {}).get("usd")
        lines.append(f"{label}: ${value:,.4f}" if value is not None else f"{label}: غير متاح")
    lines.append("\\nالمصدر: CoinGecko. الأسعار تتغير باستمرار وليست توصية استثمارية.")
    return "\\n".join(lines)


async def show_tasks(target):
    with db() as con:
        rows = con.execute("SELECT * FROM tasks WHERE active=1 ORDER BY id DESC LIMIT 15").fetchall()
    if not rows:
        await target.reply_text("لا توجد مهام مضافة حالياً. ارجع لاحقاً.")
        return
    for row in rows:
        text = f"🎯 {row['title']}\\n{row['description']}"
        if row["url"]:
            text += f"\\nالرابط: {row['url']}"
        await target.reply_text(text)


async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    with db() as con:
        row = con.execute("SELECT points FROM users WHERE user_id=?", (uid,)).fetchone()
    points = row["points"] if row else 0
    await update.effective_message.reply_text(f"💰 رصيدك المسجل: {points:g} نقطة.\\nهذه نقاط داخل البوت وليست عملة أو رصيداً نقدياً.")


async def withdraw_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["awaiting_withdraw"] = True
    await update.effective_message.reply_text(
        "لإرسال طلب سحب اكتب في رسالة واحدة:\\n"
        "/withdraw المبلغ عنوان_محفظتك\\n\\n"
        "مثال: /withdraw 10 TYourWalletAddress\\n"
        "لا ترسل أبداً المفتاح الخاص أو عبارة الاسترداد. الطلب يُراجع يدوياً ولا يعني ضمان الدفع."
    )


async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("الاستخدام: /withdraw المبلغ عنوان_المحفظة")
        return
    try:
        amount = float(context.args[0])
        wallet = " ".join(context.args[1:])
        if amount <= 0 or amount > 1_000_000 or len(wallet) < 8:
            raise ValueError()
    except ValueError:
        await update.message.reply_text("تحقق من المبلغ وعنوان المحفظة.")
        return
    uid = update.effective_user.id
    with db() as con:
        row = con.execute("SELECT points FROM users WHERE user_id=?", (uid,)).fetchone()
        if not row or row["points"] < amount:
            await update.message.reply_text("رصيد النقاط غير كافٍ لهذا الطلب.")
            return
        cur = con.execute(
            "INSERT INTO withdrawals(user_id, amount, wallet, created_at) VALUES(?,?,?,?)",
            (uid, amount, wallet, datetime.now(timezone.utc).isoformat())
        )
        request_id = cur.lastrowid
    await update.message.reply_text(f"تم تسجيل طلب السحب رقم #{request_id} للمراجعة. لم يتم إرسال أي أموال بعد.")
    if ADMIN_ID:
        try:
            await context.bot.send_message(
                ADMIN_ID,
                f"طلب سحب جديد #{request_id}\\nالمستخدم: {uid}\\nالمبلغ: {amount:g}\\nالمحفظة: {wallet}\\n"
                f"للموافقة: /approve {request_id}\\nللرفض: /reject {request_id}"
            )
        except Exception:
            log.exception("Could not notify admin")


async def approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("استخدم: /approve رقم_الطلب")
        return
    rid = int(context.args[0])
    with db() as con:
        row = con.execute("SELECT * FROM withdrawals WHERE id=? AND status='pending'", (rid,)).fetchone()
        if not row:
            await update.message.reply_text("الطلب غير موجود أو تمت مراجعته.")
            return
        user = con.execute("SELECT points FROM users WHERE user_id=?", (row["user_id"],)).fetchone()
        if not user or user["points"] < row["amount"]:
            await update.message.reply_text("لا يمكن الموافقة: رصيد النقاط غير كافٍ.")
            return
        con.execute("UPDATE users SET points=points-? WHERE user_id=?", (row["amount"], row["user_id"]))
        con.execute("UPDATE withdrawals SET status='approved' WHERE id=?", (rid,))
    await update.message.reply_text(f"تم اعتماد الطلب #{rid}. نفّذ التحويل يدوياً من خلال مزود موثوق.")
    await context.bot.send_message(row["user_id"], f"تم اعتماد طلبك #{rid}. تواصل مع الإدارة لمعرفة حالة التحويل.")


async def reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("استخدم: /reject رقم_الطلب")
        return
    rid = int(context.args[0])
    with db() as con:
        cur = con.execute("UPDATE withdrawals SET status='rejected' WHERE id=? AND status='pending'", (rid,))
    await update.message.reply_text("تم رفض الطلب." if cur.rowcount else "الطلب غير موجود أو تمت مراجعته.")


async def addtask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    raw = update.message.text.partition(" ")[2].strip()
    parts = raw.split("|", 2)
    if len(parts) < 2:
        await update.message.reply_text("استخدم: /addtask العنوان | الوصف | الرابط_اختياري")
        return
    title, description = parts[0].strip(), parts[1].strip()
    url = parts[2].strip() if len(parts) == 3 else ""
    with db() as con:
        con.execute("INSERT INTO tasks(title, description, url) VALUES(?,?,?)", (title, description, url))
    await update.message.reply_text("تمت إضافة المهمة.")


async def credit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 2:
        await update.message.reply_text("استخدم: /credit user_id amount")
        return
    try:
        uid, amount = int(context.args[0]), float(context.args[1])
        if amount <= 0:
            raise ValueError()
    except ValueError:
        await update.message.reply_text("تحقق من رقم المستخدم والمبلغ.")
        return
    with db() as con:
        cur = con.execute("UPDATE users SET points=points+? WHERE user_id=?", (amount, uid))
    await update.message.reply_text("تمت إضافة النقاط." if cur.rowcount else "المستخدم غير مسجل في البوت.")


async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    with db() as con:
        users = con.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        pending = con.execute("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'").fetchone()["n"]
    await update.message.reply_text(f"📈 المستخدمون: {users}\\nطلبات السحب المعلقة: {pending}")


async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "prices":
        try:
            await q.message.reply_text(await prices_text())
        except Exception:
            log.exception("Price API error")
            await q.message.reply_text("تعذر جلب الأسعار الآن. حاول بعد قليل.")
    elif q.data == "tasks":
        await show_tasks(q.message)
    elif q.data == "balance":
        await balance(update, context)
    elif q.data == "withdraw_help":
        await withdraw_help(update, context)
    elif q.data == "help":
        await q.message.reply_text(
            "الأوامر:\\n/start بدء البوت\\n/prices أسعار العملات\\n/tasks المهام\\n/balance رصيدي\\n"
            "/withdraw المبلغ عنوان_المحفظة طلب سحب\\n\\n"
            "للمشرف: /addtask و /credit و /stats و /approve و /reject"
        )


async def tasks_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_tasks(update.message)


async def prices_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.message.reply_text(await prices_text())
    except Exception:
        await update.message.reply_text("تعذر جلب الأسعار الآن. حاول بعد قليل.")


def main():
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Add it in Railway Variables.")
    init_db()
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("prices", prices_command))
    app.add_handler(CommandHandler("tasks", tasks_command))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("withdraw", withdraw))
    app.add_handler(CommandHandler("addtask", addtask))
    app.add_handler(CommandHandler("credit", credit))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("approve", approve))
    app.add_handler(CommandHandler("reject", reject))
    app.add_handler(CallbackQueryHandler(callback))
    log.info("SOUQNA Crypto bot is starting")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
